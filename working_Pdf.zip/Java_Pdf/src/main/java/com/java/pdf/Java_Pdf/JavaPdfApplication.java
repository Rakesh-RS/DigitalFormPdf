package com.java.pdf.Java_Pdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class JavaPdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaPdfApplication.class, args);
	}

}
