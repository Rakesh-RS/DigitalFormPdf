
package com.java.pdf.Java_Pdf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.java.pdf.Java_Pdf.Model.Employee;

@RequestMapping("/api")
@RestController
public class PdfController {

	@Autowired
	Employee emp;
	
	
	@GetMapping("/")
	public ModelAndView login()
	{
		System.out.println("jsp trigger");
		//return "index";
		return new ModelAndView("empForm");
	}
	@PostMapping("/emp")
	private String index( @RequestParam String empId, @RequestParam String empSalary, @RequestParam String empName)
	{
		 emp.getData(empId,empSalary,empName);
		
		//return emp.getName();
		//emp.createPdf();
		 emp.createTable();
		System.out.println(emp.toString());
		return "done";
	}
	@PostMapping("/empReq")
	public void emp(@RequestBody Employee em)
	{
		System.out.println(em.toString());
	}
	
}
