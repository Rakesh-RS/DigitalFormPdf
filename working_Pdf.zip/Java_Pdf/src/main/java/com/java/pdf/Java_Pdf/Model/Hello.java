package com.java.pdf.Java_Pdf.Model;

import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class Hello {

	 /**
     * Generates a PDF file with the text 'Hello World'
     * 
     * @param args no arguments needed here
     
    public static void main(String[] args) {

        System.out.println("Hello World");

        // step 1: creation of a document-object
        Document document = new Document();
        try {
            // step 2:
            // we create a writer that listens to the document
            // and directs a PDF-stream to a file
            final PdfWriter instance = PdfWriter.getInstance(document, new FileOutputStream("D:\\Users\\simple.pdf"));

            // step 3: we open the document
            document.open();
            instance.getInfo().put(PdfName.CREATOR, new PdfString(Document.getVersion()));
            // step 4: we add a paragraph to the document
            document.add(new Paragraph("Hello World"));
        } catch (DocumentException | IOException de) {
            System.err.println(de.getMessage());
        }

        // step 5: we close the document
        document.close();
    }
    */
	 public static void main(String[] args) {
	System.out.println("My First PdfPTable");

    // step 1: creation of a document-object
    Document document = new Document();

    try {
        // step 2:
        // we create a writer that listens to the document
        // and directs a PDF-stream to a file
        PdfWriter.getInstance(document, new FileOutputStream("D:\\Users\\simpleTable.pdf"));

        // step 3: we open the document
        document.open();

        PdfPTable table = new PdfPTable(2);
        PdfPCell cell = new PdfPCell(new Paragraph("Header"));
        cell.setColspan(2);
        table.addCell(cell);
        table.addCell("1.1");
        table.addCell("2.1");
        table.addCell("3.1");
        table.addCell("1.2");
        table.addCell("2.2");
        table.addCell("3.2");
        cell = new PdfPCell(new Paragraph("cell test1"));
        cell.setBorderColor(new Color(255, 0, 0));
        table.addCell(cell);
        cell = new PdfPCell(new Paragraph("cell test2"));
        cell.setColspan(2);
        cell.setBackgroundColor(new Color(0xC0, 0xC0, 0xC0));
        table.addCell(cell);
        document.add(table);
    } catch (DocumentException | IOException de) {
        System.err.println(de.getMessage());
    }

    // step 5: we close the document
    document.close();
}
	 public void table()
	 {
		 try {
		      Font font = new Font(Font.HELVETICA, 12, Font.BOLDITALIC);
		      Document doc = new Document();
		      PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream("D:\\Users\\simpleTable.pdf"));
		      PdfPTable table = new PdfPTable(2);
		      table.setWidthPercentage(100);
		      // setting column widths
		      table.setWidths(new float[] {6.0f, 6.0f});
		      PdfPCell cell = new PdfPCell();
		      // table headers
		      cell.setPhrase(new Phrase("Employee Name", font));
		      table.addCell(cell);
		      
		      cell.setPhrase(new Phrase("Empoyee ID", font));
		      table.addCell(cell);
		      cell.setPhrase(new Phrase("Employee Salary", font));
		      table.addCell(cell);
		      
		      table.addCell("Salary");
//		      List<User> users = getListOfUsers();
		      // adding table rows
//		      for(User user : users) {
//		        table.addCell(user.getFirstName());
//		        table.addCell(user.getLastName());
//		        table.addCell(user.getEmail());
//		        table.addCell(new SimpleDateFormat("dd/MM/yyyy").format(user.getDob()));
//		      }
		      doc.open();
		      // adding table to document
		      doc.add(table);
		      doc.close();
		      writer.close();
		      System.out.println("PDF using OpenPDF created successfully");
		    } catch (DocumentException | FileNotFoundException e) {
		      // TODO Auto-generated catch block
		      e.printStackTrace();
		    }
	 }
}
