package com.java.pdf.Java_Pdf.service;

import org.springframework.stereotype.Service;

@Service
public class PdfService {

}
