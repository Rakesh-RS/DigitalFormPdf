package com.java.pdf.Java_Pdf.Model;

import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;

import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfName;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfString;
import com.lowagie.text.pdf.PdfWriter;

@Component
public class Employee {

	String Id;
	String Name;
	String Salary;
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getSalary() {
		return Salary;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Salary=" + Salary + "]";
	}
	public void getData(String id,  String salary, String name) {
		
		Id = id;
		Name = name;
		Salary = salary;
	}
	public void setSalary(String salary) {
		Salary = salary;
	}
	public void createPdf()
	{
		System.out.println("Pdf Started");

        // step 1: creation of a document-object
        Document document = new Document();
        try {
            // step 2:
            // we create a writer that listens to the document
            // and directs a PDF-stream to a file
        	
            final PdfWriter instance = PdfWriter.getInstance(document, new FileOutputStream("D:\\Users\\simple.pdf"));

            // step 3: we open the document
            document.open();
            instance.getInfo().put(PdfName.CREATOR, new PdfString(Document.getVersion()));
            // step 4: we add a paragraph to the document
            document.add(new Paragraph("Employee Name:"+Name));
            document.add(new Paragraph("Employee ID:"+Id));
            document.add(new Paragraph("Employee Salary:"+Salary));
        } catch (DocumentException | IOException de) {
            System.err.println(de.getMessage());
        }

        // step 5: we close the document
        document.close();
        System.out.println("pdf created:");
		
	}
	public void createTable()
	{
		try {
		      Font font = new Font(Font.HELVETICA, 12, Font.BOLDITALIC);
		      Document doc = new Document();
//		      String path="D:\\Users\\"+Id+".pdf";
//	        	System.out.println(path);
	         
		     // PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream(path));
		      PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream("D:\\Users\\simpleTable.pdf"));
		      PdfPTable table = new PdfPTable(2);
		      table.setWidthPercentage(100);
		      // setting column widths
		      table.setWidths(new float[] {6.0f, 6.0f});
//		      PdfPCell cell1 = new PdfPCell(new Paragraph("Header"));
//		        cell1.setColspan(2);
//		        table.addCell(cell1);
		      
		      PdfPCell cell = new PdfPCell();
		      // table headers
		      cell.setPhrase(new Phrase("Employee Name", font));
		      table.addCell(cell);
		      table.addCell(Name);
		      cell.setPhrase(new Phrase("Empoyee ID", font));
		      table.addCell(cell);
		      table.addCell(Id);
		      cell.setPhrase(new Phrase("Employee Salary", font));
		      table.addCell(cell);
		      
		      table.addCell(Salary);
		      doc.open();
		      // adding table to document
		      doc.add(new Paragraph("Employee:") );
		      doc.add(new Paragraph("   "));
		      doc.add(table);
		      doc.close();
		      writer.close();
		      System.out.println("PDF  created successfully");
		    } catch (DocumentException | FileNotFoundException e) {
		      // TODO Auto-generated catch block
		      e.printStackTrace();
		    }
	}
}
