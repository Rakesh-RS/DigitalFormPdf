package com.java.pdf.Java_Pdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaPdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
